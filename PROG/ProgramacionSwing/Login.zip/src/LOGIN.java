import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Arrays;

import javax.swing.JPasswordField;

public class LOGIN extends JFrame {

	private JPanel contentPane;
	private JTextField tuser;
	private JPasswordField pass;

// EL LOGIN ES User: admin,Password: admin.
	
	
	public LOGIN() {
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent arg0) {
				confirmarSalida();
			}

			private void confirmarSalida() {
				int valor = JOptionPane.showConfirmDialog(LOGIN.this, "�Estas seguro de cerrar?","Advertencia", JOptionPane.YES_NO_OPTION);
				if(valor==JOptionPane.YES_OPTION) {
					JOptionPane.showMessageDialog(LOGIN.this, "Gracias por su visita", "Gracias", JOptionPane.INFORMATION_MESSAGE);
					System.exit(0);
				}
			}
		});
		
		
		
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		
		
		
		
		JButton btnNewButton = new JButton("Registrar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			String user = "admin";
			String contra = "admin";
			
			char[] contrase�a = contra.toCharArray();
			if (tuser.getText().equals(user) && Arrays.equals(pass.getPassword(), contrase�a )){
			 JOptionPane.showMessageDialog(LOGIN.this, "Te has logeado correctamente");
			}
			else {
			JOptionPane.showMessageDialog(LOGIN.this, "El usuario o contrase�a no son v�lidos");
			}
			}
			
		});
		
		btnNewButton.setBounds(317, 198, 89, 23);
		contentPane.add(btnNewButton);
		
		JLabel lblNombre = new JLabel("User :");
		lblNombre.setFont(new Font("Times New Roman", Font.BOLD, 12));
		lblNombre.setBounds(42, 35, 65, 14);
		contentPane.add(lblNombre);
		
		JLabel lblApellido = new JLabel("Password :");
		lblApellido.setFont(new Font("Times New Roman", Font.BOLD, 12));
		lblApellido.setBounds(21, 78, 65, 14);
		contentPane.add(lblApellido);
		
		tuser = new JTextField();
		tuser.setBounds(96, 32, 109, 20);
		contentPane.add(tuser);
		tuser.setColumns(10);
		
		pass = new JPasswordField();
		pass.setBounds(96, 75, 109, 20);
		contentPane.add(pass);
	}
}
