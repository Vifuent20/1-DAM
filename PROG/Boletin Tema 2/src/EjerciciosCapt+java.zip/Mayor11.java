
public class Mayor11 {

	public static void main(String[] args) {
		int numero1,numero2;
		numero1 = 5;
		numero2 = 6; 
		
		if (numero1>numero2)
			  System.out.println(numero1);
			else
			  System.out.println(numero2);
}
		
		
	}


