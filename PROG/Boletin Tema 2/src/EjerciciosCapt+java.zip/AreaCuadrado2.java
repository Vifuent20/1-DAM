
public class AreaCuadrado2 {

	public static void main(String[] args) {
	int lado;
	lado = 5;
	System.out.println("El area del cuadrado es de " + lado * lado + " cm");
 
	}

}
