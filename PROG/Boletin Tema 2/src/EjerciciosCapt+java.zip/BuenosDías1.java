
public class BuenosD�as1 {

	public static void main(String[] args) {
	 System.out.println("Molt Bon D�a");

	}

}
