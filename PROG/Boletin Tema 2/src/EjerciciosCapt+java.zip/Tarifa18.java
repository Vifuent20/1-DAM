import java.util.Scanner;

public class Tarifa18 {

	public static void main(String[] args) {
		 Scanner teclado = new Scanner(System.in);
				 
			int horas, tarifa,  SalarioNeto, impuestos;	 
				 tarifa = 25;
			double salarioBruto;
			double salarioBruto2;
				System.out.println("Dime las horas trabajadas");
				horas = teclado.nextInt();
				
				if (horas <= 35) {
					salarioBruto = horas * tarifa;
				}else 
					if (salarioBruto2 = (35 * tarifa) + (horas - 35) * 1.5 * tarifa) {
						
					}
				 
				 
				 
				 
				 

		 
		 
		 
		 
		 
		 
		 teclado.close();
	}

}
