
public class Precio5 {

	public static void main(String[] args) {
	double precio, pvp;
	precio = 100;
	pvp =89;
	
	double Percentage;
	Percentage = ((precio-pvp) / precio * 100); 
	System.out.println("El percentage de descuento del artico es " + Percentage+"%");

	}

}
