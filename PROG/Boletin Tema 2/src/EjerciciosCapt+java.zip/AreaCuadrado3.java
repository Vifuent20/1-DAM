import java.util.Scanner;

public class AreaCuadrado3 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		int lado;
		System.out.println("Dime el lado del cuadrado");
		lado = teclado.nextInt();
		System.out.println("El area del cuadrado es de " + lado * lado + " cm");
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	teclado.close();
	}

}
